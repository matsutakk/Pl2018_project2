﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Transport : MonoBehaviour {

    public void ToTitle(){
        SceneManager.LoadScene("Title");
    }

    public void ToLogin()
    {
        SceneManager.LoadScene("Login");
    }

    public void ToRegister()
    {
        SceneManager.LoadScene("Register");
    }

    public void ToClassRoom()
    {
        SceneManager.LoadScene("ClassRoom");
    }

    public void ToList()
    {
        SceneManager.LoadScene("List");
    }

    public void ToQuiz()
    {
        SceneManager.LoadScene("Quiz");
    }

    public void ToChat()
    {
        SceneManager.LoadScene("Chat");
    }

    public void ToEditAndAdd()
    {
        SceneManager.LoadScene("EditAndAdd");
    }



}
