﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using System;
using System.Net;
using System.Net.Sockets;
using System.IO;
using System.Text;

public class Client : MonoBehaviour
{
  //  public Text myname;
    private String clientName;
    private bool socketReady;
    private TcpClient socket;
    private NetworkStream stream;
    private StreamWriter writer;
    private StreamReader reader;
    private String username;
    private List<string> FriendsList = new List<string>();
    private Boolean isConnect = false;
    public string host = "192.168.10.101";
    public int port = 6543;
    public GameObject chatContainer;
    public GameObject messagePrefab;

    ///クイズ関連
    private static int[] quizNum = { 0 }; //出題した問題番号を記憶するための配列
    private static int quizCount = 0;   //現在の出題数

    private String[] quiz;  //問題ごとにクイズセットを格納するための配列
    private int quizMax;    //ファイル内の問題の数
    private String[] quizElements;  //問題-選択肢-答えを別々に格納するための配列
    ///クイズ関連

  

    public static Client _instance;
    // public string newUser = "";

    String display = "";
    String UserInfo;
    String Chatdata;
    void Awake()
    {
        _instance = this;
    }


    public void ConnectedToServer()
    {
        // if already connected igonore this function
        if (socketReady)
            return;

        //Default host/ port values
       // string host = "133.34.250.94";
        //int port = 6543;

        // Overwrite default host / post values, if there is something in those boxes
        //string h;
        //int p;

        // create the socket
        try
        {
            socket = new TcpClient(host, port);
            stream = socket.GetStream();
            writer = new StreamWriter(stream);
            reader = new StreamReader(stream);
            socketReady = true;

        }
        catch (Exception e)
        {
            Debug.Log("socket error : " + e.Message);
        }

    }

    private void Update()
    {
        if (socketReady)
        {
            if (stream.DataAvailable)
            {
                string data = reader.ReadLine();
                if (data != null)
                {
                    OnIncomingData(data);
                }
            }
        }


    }

    public void OnIncomingData(string data)
    {
        Debug.Log("from server : " + data);

        if (data == "##NAME##")
        {
            Send("##NAME|" + clientName);
            Debug.Log("to server :##NAME|" + clientName);
            isConnect = true;
            return;
        }

        if (data.Contains("has connected"))
            Send("GET_PASSWORD");
        
        if (data.Contains("has already existed"))
        {
            GameObject.Find("Question").GetComponent<Text>().text = "正解！でもこの人はもうリストにいたよ！";
        }

        String[] p = data.Split(' ');

        switch (p[0])
        {
            case "UserInfo": //login
                UserInfo = "username:" + p[1] + " password:" + p[2] + " date:" + p[3];
                Debug.Log(data);
                if (Transport._instance.LOGIN.activeSelf)
                {
                    string name = GameObject.Find("InputNAME").GetComponent<InputField>().text;
                    string password = GameObject.Find("InputPASS").GetComponent<InputField>().text;
                    if (name == p[1] && password == p[2])
                    {
                        GameObject.Find("InputNAME").GetComponent<InputField>().text = "";
                        GameObject.Find("InputPASS").GetComponent<InputField>().text = "";
                        GameObject.Find("LoginError").GetComponent<Text>().text = " ";

                        Transport._instance.ToClassRoom();

                    }
                    else
                    {
                        display = "username or password is not correct ";
                        GameObject.Find("LoginError").GetComponent<Text>().text = display;
                        Debug.Log(display);
                    }
                }
                else if (Transport._instance.REGISTER.activeSelf) {
                    string name = GameObject.Find("InputNAME2").GetComponent<InputField>().text;
                    string password = GameObject.Find("InputDefaultPASS").GetComponent<InputField>().text;
                    string password2 = GameObject.Find("InputNewPASS").GetComponent<InputField>().text;

                    if (name == p[1] && password == p[2]) {
                        Send("UPDATE_PASSWORD%%" + password2);
                        Debug.Log("to server:UPDATE_PASSWORD%%" + password2);
                        GameObject.Find("InputNAME2").GetComponent<InputField>().text = "";
                        GameObject.Find("InputNewPASS").GetComponent<InputField>().text = "";
                        GameObject.Find("InputDefaultPASS").GetComponent<InputField>().text = "";
                        Transport._instance.ToClassRoom();
                    }
                    else
                    {
                        display = "username or password is not correct ";
                        GameObject.Find("LoginError").GetComponent<Text>().text = display;
                        Debug.Log(display);
                    }

                }
                break;

            case "FriendList": //list appears
                for (int i = 1; i < p.Length; i++)
                    FriendsList.Add(p[i]);
                //Debug.Log(FriendsList);
                /* String[] list = FriendsList.ToArray();
                 display = "";
                 foreach (var friend in FriendsList)
                 {
                     display = display + friend + "\n";
                 }
                 Debug.Log(display);
                 GameObject.Find("FriendsList").GetComponentInChildren<Text>().text = display;
                 */
                FriendListManager._instance.AddFriend(FriendsList);
                FriendsList.Clear();

                break;
            case "ChatRecord":

                Chatdata = p[1];
                System.Text.StringBuilder sb = new System.Text.StringBuilder(Chatdata);
                sb.Replace("::", "\n");
                sb.Replace("&&", ":");
                Chatdata = sb.ToString();
                GameObject.Find("ChatContent").GetComponentInChildren<Text>().text = Chatdata;
                Debug.Log(Chatdata);
                break;

            /*--- 他人からの送信の場合 ---*/
            case "ChatRecordFromTheOther":
                Chatdata = p[1];
                // String[] n = p[1].Split("::");

                System.Text.StringBuilder stringBuilder = new System.Text.StringBuilder(Chatdata);
                stringBuilder.Replace("::", "\n");
                stringBuilder.Replace("&&", ":");
                Chatdata = stringBuilder.ToString();
                String[] n = Chatdata.Split('\n');
                Debug.Log(n[1] + n[2]);
                int l = n.Length;
                string str = n[l - 2];
                Debug.Log(str);
                String[] s = str.Split(':');
                PopUpNotice(s[0]);
                Debug.Log(s[0]);
                if (Transport._instance.CHAT.activeSelf)
                    GameObject.Find("ChatContent").GetComponentInChildren<Text>().text = Chatdata;
                Debug.Log(Chatdata);

                break;


            case "Quiz":
                //クイズセットの割り当て。quiz[0]はファイル内の問題数を示し、クイズセットはquiz[1]以降
                quiz = data.Split('/');

                //所持問題数の把握
                String quizMaxStr;

                quizMaxStr = quiz[0].Substring(5, 1);   //例 quiz[0]=Quiz5 ：ファイル内にはクイズは5問存在
                quizMax = int.Parse(quizMaxStr);

                //初期化
                quizNum = new int[4];   //出題した問題番号を記憶するための配列。配列quizと対応させるためquizNum[0]は空
                quizCount = 1;          //現在の問題は第何問か？


                quizDisp(quiz,quizMax);
                break;
        }

    }

    ///クイズの出題///
    public void quizDisp(String[] quiz,int quizMax){  


        System.Random r = new System.Random();
        int num = 0;

        //出題問題の決定
        do{
            num = r.Next(1,quizMax+1);
        } while (num == quizNum[1] || num == quizNum[2]);   //前に出した問題と被っていないか

        quizNum[quizCount] = num;

        //クイズの割り当て
        quizElements = quiz[quizNum[quizCount]].Split(' ');

        //問題や選択肢の表示
        GameObject.Find("Question").GetComponent<Text>().text = quizElements[0];
        GameObject.Find("Answer1").GetComponentInChildren<Text>().text = quizElements[1];
        GameObject.Find("Answer2").GetComponentInChildren<Text>().text = quizElements[2];
        GameObject.Find("Answer3").GetComponentInChildren<Text>().text = quizElements[3];

        //第(quizCount++)問へ
        quizCount++;
    }

    ///回答の正誤判断///
    public Boolean RightOrWrongDecision(String a, String b) 
    {
        if (a.Equals(b))
            return true;
        else
            return false;
    }


    ///選択肢ボタンを押した際の処理///
    public void Submisson(String clickButton)
    {
        //押されたボタンのテキストを取得
        Debug.Log(clickButton);
        string UserAnswer = GameObject.Find(clickButton).GetComponentInChildren<Text>().text;

        //正解の時
        if (RightOrWrongDecision(quizElements[4], UserAnswer))
        {   
            GameObject.Find("QUIZCanvas").transform.Find("maru").gameObject.SetActive(true);

            //1,2問目の時
            if (quizCount < 4)
            {
                GameObject.Find("QUIZCanvas").transform.Find("nextquiz").gameObject.SetActive(true);

            }
            //3問目の時
            else
            {
                Send("INSERT_FRIENDSLIST%%" + username);
                Debug.Log("to server:" + "INSERT_FRIENDSLIST%%" + username);

                GameObject.Find("QUIZCanvas").transform.Find("GoToList(Finish)").gameObject.SetActive(true);
                GameObject.Find("Answer1").GetComponent<Button>().interactable = false;
                GameObject.Find("Answer2").GetComponent<Button>().interactable = false;
                GameObject.Find("Answer3").GetComponent<Button>().interactable = false;

            }

        }
        //不正解の時
        else
        {
            GameObject.Find("QUIZCanvas").transform.Find("batsu").gameObject.SetActive(true);
            GameObject.Find("QUIZCanvas").transform.Find("GoToList(Finish)").gameObject.SetActive(true);
            GameObject.Find("Answer1").GetComponent<Button>().interactable = false;
            GameObject.Find("Answer2").GetComponent<Button>().interactable = false;
            GameObject.Find("Answer3").GetComponent<Button>().interactable = false;
            Debug.Log("Wrong");
        }

    }

    public void NextQuiz(){
        GameObject.Find("nextquiz").SetActive(false);
        GameObject.Find("maru").SetActive(false);
        quizDisp(quiz, quizMax);
    }


    /*  public void SendChatRoomInfo()
      {
          string s = ChatRoomPanel.input_Context.text;
          Send("UPDATE_CHAT_HISTORY%%" + username + "%%" + s);

          ChatRoomPanel.input_Context.text = "";
          Send("ChatRoom" + " " + s);
          ChatRoomPanel.UpdateTextPanel(clientName + ":" + s);
      }*/




    /*  public void RequestChat(string name)　//chatのrequest
      {
          String name1 = GameObject.Find("Target").GetComponent<InputField>().text;
          String Message=GameObject.Find("Message").GetComponent<InputField>().text;
          Send("UPDATE_CHAT_HISTORY%%" + name1 +"%%" +Message);
          Debug.Log("UPDATE_CHAT_HISTORY%%" + name1 + "%%" + Message);

      }*/


    public void OnChatSend()
    {
        String message = GameObject.Find("SendInput").GetComponent<InputField>().text;
        Debug.Log(clientName + " has sent the followinng message from client: " + message);

        Send("UPDATE_CHAT_HISTORY%%" + username + "%%" + message);
        GameObject.Find("SendInput").GetComponent<InputField>().text = "";


    }


    private void Send(string data)
    {
        if (!socketReady)
            return;

        writer.WriteLine(data);
        writer.Flush();

    }

    public void ToTitle()
    {
        Transport._instance.ToTitle();
        //socket.Close();

        socketReady = false;
        reader.Close();
        isConnect = false;

    }
    public void Close()
    {
        socket.Close();
        socketReady = false;
    }
    public void ToLogin()
    {
        //ConnectedToServer();
        Transport._instance.ToLogin();
    }

    public void ToRegister()
    {
        // ConnectedToServer();
        Transport._instance.ToRegister();
    }

    public void LoginFinishToClassRoom()
    {
        clientName = GameObject.Find("InputNAME").GetComponent<InputField>().text;
        if (!isConnect)
        {
            ConnectedToServer();
        }
        else
            Send("GET_PASSWORD");



    }
    public void RegisterFinishToClassRoom()
    {
        clientName = GameObject.Find("InputNAME2").GetComponent<InputField>().text;
        if (!isConnect)
        {
            ConnectedToServer();
        }
        else
        {
            Send("GET_PASSWORD");
        }

    }
    public void ToList()
    {
        Send("GET_FRIENDSLIST");
        Transport._instance.ToList();

    }

    public void ToQuiz(String name)
    {
        // username = GameObject.Find("Name").GetComponent<InputField>().text;

        Transport._instance.ToQuiz();

        GameObject.Find("QUIZCanvas").transform.Find("maru").gameObject.SetActive(false);    //クイズの時○×をしまう
        GameObject.Find("QUIZCanvas").transform.Find("batsu").gameObject.SetActive(false);
        GameObject.Find("QUIZCanvas").transform.Find("GoToList(Finish)").gameObject.SetActive(false);//不要なボタンをしまう

        GameObject.Find("Answer1").GetComponent<Button>().interactable = true;
        GameObject.Find("Answer2").GetComponent<Button>().interactable = true;
        GameObject.Find("Answer3").GetComponent<Button>().interactable = true;

        Send("GET_QUIZ%%" + name);

    }
    public void ChatUpdate()
    {
        Send("GET_CHAT_HISTORY%%" + username);
    }
    public void ToChat(String name)
    {
        // username = GameObject.Find("Name").GetComponent<InputField>().text;
        Transport._instance.ToChat();
        username = name;
        GameObject.Find("chathead").GetComponent<Text>().text = "To" + username;
        Send("GET_CHAT_HISTORY%%" + username);
        Debug.Log("GET_CHAT_HISTORY%%" + username);


    }

    public void ToEditAndAdd(String name)
    {
        Transport._instance.ToEditAndAdd();
        username = name;
    }

    /*---  通知 ---*/
    public void PopUpNotice(String name)
    {
        Transport._instance.PopUpNotice();
        GameObject.Find("Notice").GetComponent<Text>().text = "Message from" + name;

    }

    public void EraseNotice()
    {
        Transport._instance.EraseNotice();
    }


}
