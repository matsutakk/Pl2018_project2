﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Transport : MonoBehaviour
{
    public GameObject CLASSROOM;
    public GameObject TITLE;
    public GameObject LOGIN;
    public GameObject REGISTER;
    public GameObject QUIZ;
    public GameObject LIST;
    public GameObject CHAT;
    public GameObject EDITANDADD;

    /*--- 通知 ---*/
    public GameObject NOTICE;


    public static Transport _instance;
    void Awake()
    {
        _instance = this;
    }


    public void ToTitle()
    {
        CLASSROOM.SetActive(false);
        TITLE.SetActive(true);
        LOGIN.SetActive(false);
        REGISTER.SetActive(false);
        QUIZ.SetActive(false);
        LIST.SetActive(false);
        CHAT.SetActive(false);
        EDITANDADD.SetActive(false);
    }

    public void ToLogin()
    {
        CLASSROOM.SetActive(false);
        TITLE.SetActive(false);
        LOGIN.SetActive(true);
        REGISTER.SetActive(false);
        QUIZ.SetActive(false);
        LIST.SetActive(false);
        CHAT.SetActive(false);
        EDITANDADD.SetActive(false);
    }

    public void ToRegister()
    {
        CLASSROOM.SetActive(false);
        TITLE.SetActive(false);
        LOGIN.SetActive(false);
        REGISTER.SetActive(true);
        QUIZ.SetActive(false);
        LIST.SetActive(false);
        CHAT.SetActive(false);
        EDITANDADD.SetActive(false);
    }

    public void ToClassRoom()
    {
        CLASSROOM.SetActive(true);
        TITLE.SetActive(false);
        LOGIN.SetActive(false);
        REGISTER.SetActive(false);
        QUIZ.SetActive(false);
        LIST.SetActive(false);
        CHAT.SetActive(false);
        EDITANDADD.SetActive(false);
    }

    public void ToList()
    {
        CLASSROOM.SetActive(false);
        TITLE.SetActive(false);
        LOGIN.SetActive(false);
        REGISTER.SetActive(false);
        QUIZ.SetActive(false);
        LIST.SetActive(true);
        CHAT.SetActive(false);
        EDITANDADD.SetActive(false);
    }

    public void ToQuiz()
    {
        CLASSROOM.SetActive(false);
        TITLE.SetActive(false);
        LOGIN.SetActive(false);
        REGISTER.SetActive(false);
        QUIZ.SetActive(true);
        LIST.SetActive(false);
        CHAT.SetActive(false);
        EDITANDADD.SetActive(false);
    }

    public void ToChat()
    {
        CLASSROOM.SetActive(false);
        TITLE.SetActive(false);
        LOGIN.SetActive(false);
        REGISTER.SetActive(false);
        QUIZ.SetActive(false);
        LIST.SetActive(false);
        CHAT.SetActive(true);
        EDITANDADD.SetActive(false);
    }

    public void ToEditAndAdd()
    {
        CLASSROOM.SetActive(false);
        TITLE.SetActive(false);
        LOGIN.SetActive(false);
        REGISTER.SetActive(false);
        QUIZ.SetActive(false);
        LIST.SetActive(false);
        CHAT.SetActive(false);
        EDITANDADD.SetActive(true);
    }


    /*---  通知 ---*/
    public void PopUpNotice()
    {
        NOTICE.SetActive(true);
    }

    public void EraseNotice()
    {
        NOTICE.SetActive(false);
    }


}
