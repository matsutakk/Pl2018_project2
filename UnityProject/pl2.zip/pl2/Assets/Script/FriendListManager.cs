﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class FriendListManager : MonoBehaviour {

    public static FriendListManager _instance;
    public Button btn;
    public Transform friendWindow;
    void Awake()
    {
        _instance = this;
    }                                                                     

    public void AddFriend(List<string> s)
    {
        foreach (var friend in s)
        {
            Button b = Instantiate<Button>(btn, friendWindow);
            b.transform.Find("Text").GetComponent<Text>().text = friend;
           // b.onClick.AddListener(delegate () { Client._instance.RequestChat(friend); });

        }

    }
    void Destroy()
    {

    }
}
