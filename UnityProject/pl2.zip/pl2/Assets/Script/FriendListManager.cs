﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class FriendListManager : MonoBehaviour
{

    public static FriendListManager _instance = new FriendListManager();
    //public Button Chat;
    //public Button Quiz;
    //public Text Friend;
    //public Transform friendWindow;
    public GameObject listPref;
    void Awake()
    {
        _instance = this;
    }
    /* public void Update() {
         if (Client._instance.FriendsList == null)
             return;
         else
             AddFriend(Client._instance.FriendsList);
     }*/

    public void AddFriend(List<string> s)
    {
        for (int i = 0; i < GameObject.Find("FriendsList/Viewport/Content").transform.childCount; i++)
        {
            GameObject go = GameObject.Find("FriendsList/Viewport/Content").transform.GetChild(i).gameObject;
            Destroy(go);
        }
        if (s == null)
        {

        }
        RectTransform content = GameObject.Find("FriendsList/Viewport/Content").GetComponent<RectTransform>();
        foreach (var friend in s)
        {
            // Button b1 = Instantiate<Button>(Chat, friendWindow);
            // Button b2 = Instantiate<Button>(Quiz, friendWindow);
            GameObject list = (GameObject)Instantiate(listPref);

            list.transform.SetParent(content, false);
            list.transform.Find("Text").GetComponent<Text>().text = friend;
            list.transform.Find("Chat").GetComponent<Button>().onClick.AddListener(() => Client._instance.ToChat(friend));
            list.transform.Find("Quiz").GetComponent<Button>().onClick.AddListener(() => Client._instance.ToQuiz(friend));
            list.transform.Find("EditandAdd").GetComponent<Button>().onClick.AddListener(() => Client._instance.ToEditAndAdd(friend));

        }
    }
    void Destroy()
    {
        Destroy(this);
    }
}