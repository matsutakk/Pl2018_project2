﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using System;
using System.Net;
using System.Net.Sockets;
using System.IO;
using System.Text;

public class Client : MonoBehaviour
{
    public Text myname;
    private String clientName;
    private bool socketReady;
    private TcpClient socket;
    private NetworkStream stream;
    private StreamWriter writer;
    private StreamReader reader;
    private String quizdata;
    private String username;
    public List<string> FriendsList = new List<string>();
    public Boolean isConnect = false;

    public GameObject chatContainer;
    public GameObject messagePrefab;


    public static Client _instance;
    // public string newUser = "";

    String display = "";
    String UserInfo;
    String Chatdata;
    void Awake()
    {
        _instance = this;
    }


    public void ConnectedToServer()
    {
        // if already connected igonore this function
        if (socketReady)
            return;

        //Default host/ port values
        string host = "127.0.0.1";
        int port = 6321;

        // Overwrite default host / post values, if there is something in those boxes
        //string h;
        //int p;

        // create the socket
        try
        {
            socket = new TcpClient(host, port);
            stream = socket.GetStream();
            writer = new StreamWriter(stream);
            reader = new StreamReader(stream);
            socketReady = true;

        }
        catch (Exception e)
        {
            Debug.Log("socket error : " + e.Message);
        }

    }

    private void Update()
    {
        if (socketReady)
        {
            if (stream.DataAvailable)
            {
                string data = reader.ReadLine();
                if (data != null)
                {
                    OnIncomingData(data);
                }
            }
        }


    }

    private void OnIncomingData(string data)
    {
        Debug.Log("from server : " + data);
        if (data == "##NAME##")
        {
            Send("##NAME|" + clientName);
            Debug.Log("to server :##NAME|" + clientName);
            isConnect = true;
            return;
        }
        if (data.Contains("has connected"))
            Send("GET_PASSWORD");
        if (data.Contains("has already existed"))
        {
            GameObject.Find("QuizResult").GetComponent<Text>().text = "正解！でもこの人はもうリストにいたよ！";
        }
        String[] p = data.Split(' ');
        switch (p[0])
        {
            case "UserInfo": //login
                UserInfo = "username:" + p[1] + " password:" + p[2] + " date:" + p[3];
                Debug.Log(data);
                string name = GameObject.Find("InputNAME").GetComponent<InputField>().text;
                string password = GameObject.Find("InputPASS").GetComponent<InputField>().text;
                if (name == p[1] && password == p[2])
                {
                    GameObject.Find("InputNAME").GetComponent<InputField>().text = "";
                    GameObject.Find("InputPASS").GetComponent<InputField>().text = "";

                    Transport._instance.ToClassRoom();


                }
                else
                {
                    display = "username or password is not correct ";
                    GameObject.Find("LoginError").GetComponent<Text>().text = display;
                    Debug.Log(display);
                }
                break;
            case "FriendList": //list appears
                for (int i = 1; i < p.Length; i++)
                    FriendsList.Add(p[i]);
                //Debug.Log(FriendsList);
                /* String[] list = FriendsList.ToArray();
                 display = "";
                 foreach (var friend in FriendsList)
                 {
                     display = display + friend + "\n";
                 }
                 Debug.Log(display);
                 GameObject.Find("FriendsList").GetComponentInChildren<Text>().text = display;
                 */
                FriendListManager._instance.AddFriend(FriendsList);
                FriendsList.Clear();

                break;
            case "ChatRecord":

                Chatdata = p[1];
                System.Text.StringBuilder sb = new System.Text.StringBuilder(Chatdata);
                sb.Replace("::", "\n");
                sb.Replace("&&", ":");
                Chatdata = sb.ToString();
                GameObject.Find("ChatContent").GetComponentInChildren<Text>().text = Chatdata;
                Debug.Log(Chatdata);
                break;

            /*--- 他人からの送信の場合 ---*/
            case "ChatRecordFromTheOther":
                Chatdata = p[1];
                // String[] n = p[1].Split("::");

                System.Text.StringBuilder stringBuilder = new System.Text.StringBuilder(Chatdata);
                stringBuilder.Replace("::", "\n");
                stringBuilder.Replace("&&", ":");
                Chatdata = stringBuilder.ToString();
                String[] n = Chatdata.Split('\n');
                Debug.Log(n[1] + n[2]);
                int l = n.Length;
                string str = n[l - 2];
                Debug.Log(str);
                String[] s = str.Split(':');
                PopUpNotice(s[0]);
                Debug.Log(s[0]);
                if (Transport._instance.CHAT.activeSelf)
                    GameObject.Find("ChatContent").GetComponentInChildren<Text>().text = Chatdata;
                Debug.Log(Chatdata);

                break;


            case "Quiz":
                quizdata = username + " " + p[1] + " " + p[2] + " " + p[3] + " " + p[4] + " " + p[5];
                display = "問題" + p[1] + "\n" + p[2] + "    " + p[3] + "    " + p[4];
                GameObject.Find("Question").GetComponent<Text>().text = display;
                break;


        }

    }
    /*  public void SendChatRoomInfo()
      {
          string s = ChatRoomPanel.input_Context.text;
          Send("UPDATE_CHAT_HISTORY%%" + username + "%%" + s);

          ChatRoomPanel.input_Context.text = "";
          Send("ChatRoom" + " " + s);
          ChatRoomPanel.UpdateTextPanel(clientName + ":" + s);
      }*/
    public Boolean RightOrWrongDecision(String a, String b) //quiz回答の正誤判断
    {
        if (a.Equals(b))
            return true;
        else
            return false;
    }


    /*  public void RequestChat(string name)　//chatのrequest
      {
          String name1 = GameObject.Find("Target").GetComponent<InputField>().text;
          String Message=GameObject.Find("Message").GetComponent<InputField>().text;
          Send("UPDATE_CHAT_HISTORY%%" + name1 +"%%" +Message);
          Debug.Log("UPDATE_CHAT_HISTORY%%" + name1 + "%%" + Message);

      }*/

    public void Submisson()
    {
        string UserAnswer = GameObject.Find("Answer").GetComponent<InputField>().text;
        String[] p = quizdata.Split(' ');
        if (RightOrWrongDecision(p[5], UserAnswer))
        {
            GameObject.Find("QuizResult").GetComponent<Text>().text = "正解！友達リストに追加成功！";
            Send("INSERT_FRIENDSLIST%%" + username);
            Debug.Log("to server:" + "INSERT_FRIENDSLIST%%" + username);

        }
        else
        {
            GameObject.Find("QuizResult").GetComponent<Text>().text = "惜しい！";
            Debug.Log("Wrong");
        }

    }
    public void OnChatSend()
    {
        String message = GameObject.Find("SendInput").GetComponent<InputField>().text;
        Debug.Log(clientName + " has sent the followinng message from client: " + message);

        Send("UPDATE_CHAT_HISTORY%%" + username + "%%" + message);
        GameObject.Find("SendInput").GetComponent<InputField>().text = "";


    }


    private void Send(string data)
    {
        if (!socketReady)
            return;

        writer.WriteLine(data);
        writer.Flush();

    }

    public void ToTitle()
    {
        Transport._instance.ToTitle();
        //socket.Close();

        socketReady = false;
        reader.Close();
        isConnect = false;

    }
    public void Close()
    {
        socket.Close();
        socketReady = false;
    }
    public void ToLogin()
    {
        //ConnectedToServer();
        Transport._instance.ToLogin();
    }

    public void ToRegister()
    {
        // ConnectedToServer();
        Transport._instance.ToRegister();
    }

    public void LoginFinishToClassRoom()
    {
        clientName = GameObject.Find("InputNAME").GetComponent<InputField>().text;
        if (!isConnect)
        {
            ConnectedToServer();
        }



    }
    public void RegisterFinishToClassRoom()
    {
        string password = GameObject.Find("InputNewPASS").GetComponent<InputField>().text;
        Send("UPDATE_PASSWORD%%" + password);
        Debug.Log("UPDATE_PASSWORD%%" + password);

        Transport._instance.ToClassRoom();

    }
    public void ToList()
    {
        Send("GET_FRIENDSLIST");
        Transport._instance.ToList();

    }

    public void ToQuiz(String name)
    {
        // username = GameObject.Find("Name").GetComponent<InputField>().text;

        Transport._instance.ToQuiz();
        Send("GET_QUIZ%%" + name);

    }
    public void ChatUpdate()
    {
        Send("GET_CHAT_HISTORY%%" + username);
    }
    public void ToChat(String name)
    {
        // username = GameObject.Find("Name").GetComponent<InputField>().text;
        Transport._instance.ToChat();
        username = name;
        GameObject.Find("chathead").GetComponent<Text>().text = "To" + username;
        Send("GET_CHAT_HISTORY%%" + username);
        Debug.Log("GET_CHAT_HISTORY%%" + username);


    }

    public void ToEditAndAdd(String name)
    {
        Transport._instance.ToEditAndAdd();
        username = name;
    }

    /*---  通知 ---*/
    public void PopUpNotice(String name)
    {
        Transport._instance.PopUpNotice();
        GameObject.Find("Notice").GetComponent<Text>().text = "Message from" + name;

    }

    public void EraseNotice()
    {
        Transport._instance.EraseNotice();
    }


}
