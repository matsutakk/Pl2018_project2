﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using System;
using System.Net;
using System.Net.Sockets;
using System.IO;
using System.Text;

public class Client: MonoBehaviour {
    public String clientName;
    private bool socketReady;
    private TcpClient socket;
    private NetworkStream stream;
    private StreamWriter writer;
    private StreamReader reader;
    private String quizdata;
    private String username;
    private List<string> FriendsList = new List<string>();
    public GameObject CLASSROOM;
    public GameObject TITLE;
    public GameObject LOGIN;
    public GameObject REGISTER;
    public GameObject QUIZ;
    public GameObject LIST;
    public GameObject CHAT;
    public GameObject EDITANDADD;

    // public static Client _instance;
    // public string newUser = "";

    String display = "";
    String OthersName;
    String UserInfo;
   //  void Awake()
    //  {
      //    _instance = this;
      //}


    public void ConnectedToServer()
    {
        // if already connected igonore this function
        if (socketReady)
            return;

        //Default host/ port values
        string host = "127.0.0.1";
        int port = 6321;

        // Overwrite default host / post values, if there is something in those boxes
        //string h;
        //int p;

        // create the socket
        try
        {
            socket = new TcpClient(host, port);
            stream = socket.GetStream();
            writer = new StreamWriter(stream);
            reader = new StreamReader(stream);
            socketReady = true;

        }
        catch (Exception e)
        {
            Debug.Log("socket error : " + e.Message);
        }

    }

    private void Update()
    {
        if (socketReady)
        {
            if (stream.DataAvailable)
            {
                string data = reader.ReadLine();
                if (data != null)
                {
                    OnIncomingData(data);
                }
            }
        }

    }

    private void OnIncomingData(string data)
    {
        Debug.Log("from server : " + data);
        if (data == "##NAME##")
        {
            Send("##NAME|" + clientName);
            Debug.Log("to server :##NAME|" + clientName);
            return;
        }
        String[] p = data.Split(' ');
        switch (p[0])
        {
            case "UserInfo": //login
                UserInfo = "username:" + p[1] + " password:" + p[2] + " date:" + p[3];
                Debug.Log(data);
                string name = GameObject.Find("InputNAME").GetComponent<InputField>().text;
                string password = GameObject.Find("InputPASS").GetComponent<InputField>().text;
                if (name == p[1] && password == p[2])
                 {
                    CLASSROOM.SetActive(true);
                    TITLE.SetActive(false);
                    LOGIN.SetActive(false);
                    REGISTER.SetActive(false);
                    QUIZ.SetActive(false);
                    LIST.SetActive(false);
                    CHAT.SetActive(false);
                    EDITANDADD.SetActive(false);
                }
                 else
                 {
                     display = "username or password is not correct ";
                     GameObject.Find("LoginError").GetComponent<Text>().text = display;
                     Debug.Log(display);
                 }
                break;  
            case "FriendList":
                for (int i = 1; i < p.Length; i++)
                    FriendsList.Add(p[i]);
                FriendListManager._instance.AddFriend(FriendsList);
                break;
            case "ChatRecord":
                GameObject.Find("ChatContent").GetComponent<Text>().text = p[1];
                Debug.Log(p[1]);
                break;
            case "Quiz":
                quizdata = OthersName+" "+p[1] + " " + p[2] + " " + p[3] + " " + p[4] + " " + p[5] ;
                display = "問題" + p[1] + "\n" + p[2] + "    " + p[3] + "    " + p[4];
                GameObject.Find("Question").GetComponent<Text>().text = display;
                break;


        }

    }
    public Boolean RightOrWrongDecision(String a,String b) //quiz回答の正誤判断
    {
        if (a.Equals(b))
            return true;
        else
            return false;
    }


    public void RequestChat(string name)　//chatのrequest
    {
        String name1 = GameObject.Find("Target").GetComponent<InputField>().text;
        String Message=GameObject.Find("Message").GetComponent<InputField>().text;
        Send("UPDATE_CHAT_HISTORY%%" + name1 +"%%" +Message);
        Debug.Log("UPDATE_CHAT_HISTORY%%" + name1 + "%%" + Message);

    }
    public void Submisson()
    {
        string UserAnswer= GameObject.Find("Answer").GetComponent<InputField>().text;
        String[] p = quizdata.Split(' ');
        if (RightOrWrongDecision(p[5], UserAnswer))
        {
            GameObject.Find("Question").GetComponent<Text>().text = "正解！友達リストに追加成功！";
            Send("INSERT_FRIENDSLIST%%"+username);
            Debug.Log("to server:" + "INSERT_FRIENDSLIST%%" + username);

        }
        else {
            GameObject.Find("Question").GetComponent<Text>().text = "Wrong";
            Debug.Log("Wrong");
        }

    }
    private void Send(string data)
    {
        if (!socketReady)
            return;

        writer.WriteLine(data);
        writer.Flush();

    }

    public void ToTitle(){
        CLASSROOM.SetActive(false);
        TITLE.SetActive(true);
        LOGIN.SetActive(false);
        REGISTER.SetActive(false);
        QUIZ.SetActive(false);
        LIST.SetActive(false);
        CHAT.SetActive(false);
        EDITANDADD.SetActive(false);

        reader.Close();
        socket.Close();
        socketReady = false;

    }
    public void Close()
    {
        socket.Close();
        socketReady = false;
    }
    public void ToLogin()
    {
        ConnectedToServer();

        CLASSROOM.SetActive(false);
        TITLE.SetActive(false);
        LOGIN.SetActive(true);
        REGISTER.SetActive(false);
        QUIZ.SetActive(false);
        LIST.SetActive(false);
        CHAT.SetActive(false);
        EDITANDADD.SetActive(false);

    }

    public void ToRegister()
    {
        ConnectedToServer();

        CLASSROOM.SetActive(false);
        TITLE.SetActive(false);
        LOGIN.SetActive(false);
        REGISTER.SetActive(true);
        QUIZ.SetActive(false);
        LIST.SetActive(false);
        CHAT.SetActive(false);
        EDITANDADD.SetActive(false);
    }

    public void LoginFinishToClassRoom()
    {
        Send("GET_PASSWORD");
        Debug.Log("to server:GET_PASSWORD");
  


    }
    public void RegisterFinishToClassRoom()
    {
        string password = GameObject.Find("InputNewPASS").GetComponent<InputField>().text;
        Send("UPDATE_PASSWORD%%"+password);
        Debug.Log("UPDATE_PASSWORD%%" + password);

        CLASSROOM.SetActive(true);
        TITLE.SetActive(false);
        LOGIN.SetActive(false);
        REGISTER.SetActive(false);
        QUIZ.SetActive(false);
        LIST.SetActive(false);
        CHAT.SetActive(false);
        EDITANDADD.SetActive(false);
    }
    public void ToList()
    {
        CLASSROOM.SetActive(false);
        TITLE.SetActive(false);
        LOGIN.SetActive(false);
        REGISTER.SetActive(false);
        QUIZ.SetActive(false);
        LIST.SetActive(true);
        CHAT.SetActive(false);
        EDITANDADD.SetActive(false);
    }

    public void ToQuiz()
    {
        username = GameObject.Find("Name").GetComponent<InputField>().text;
        Send("GET_QUIZ%%" + username);

        CLASSROOM.SetActive(false);
        TITLE.SetActive(false);
        LOGIN.SetActive(false);
        REGISTER.SetActive(false);
        QUIZ.SetActive(true);
        LIST.SetActive(false);
        CHAT.SetActive(false);
        EDITANDADD.SetActive(false);
    }

    public void ToChat()
    {
        CLASSROOM.SetActive(false);
        TITLE.SetActive(false);
        LOGIN.SetActive(false);
        REGISTER.SetActive(false);
        QUIZ.SetActive(false);
        LIST.SetActive(false);
        CHAT.SetActive(true);
        EDITANDADD.SetActive(false);
    }

    public void ToEditAndAdd()
    {
        CLASSROOM.SetActive(false);
        TITLE.SetActive(false);
        LOGIN.SetActive(false);
        REGISTER.SetActive(false);
        QUIZ.SetActive(false);
        LIST.SetActive(false);
        CHAT.SetActive(false);
        EDITANDADD.SetActive(true);
    }



}
